# Modificaciones para Gamma — Mi Plan de Vuelo

Guía completa de edición. Sigue el orden: primero los 2 cambios globales, luego módulo por módulo.

**Antes de empezar:** reemplaza `[TU-SITIO]` en todos los links de abajo por el dominio real que te dio Netlify (ej: `mi-plan-de-vuelo.netlify.app`).

---

## 1. Cambios globales (no son de un módulo específico)

### 1.1 — Portada / hook inicial
Busca donde dice:
> 📊 Excel automatizado — Precios, costos y proyección a 6 meses

Reemplázalo por:
> 🖥️ Plataforma web interactiva — Completa cada módulo en minutos. Sin fórmulas. Sin complicaciones. Solo clic y avanza.

### 1.2 — Módulo 1, página completa "Qué vas a lograr y cómo usar este kit"
Reemplaza toda esa página por esta versión (ya incluye la corrección de 30→20 min, la fusión con la comparación Guía/Plataforma, y el aviso de respaldo completo):

> **QUÉ VAS A LOGRAR Y CÓMO USAR ESTE KIT**
>
> **🎯 Objetivo:** Tener claridad sobre lo que vas a construir y qué puedes esperar al final.
>
> **TU TRANSFORMACIÓN EN 30 DÍAS**
>
> | HOY | EN 30 DÍAS |
> |---|---|
> | Idea sin estructura | Idea validada + cliente definido |
> | No sabes cuánto cobrar | Precio, costo y meta claros |
> | El tiempo se va sin avanzar | Sistema de 20 min/día que funciona |
> | Miedo al qué dirán | Primeras ventas reales |
>
> Solo necesitas una idea (o ganas de encontrarla) y 20 minutos al día.
>
> **CÓMO FUNCIONA**
>
> 📖 **La Guía** te explica el qué y el por qué, con ejemplos de Sofía.
> 🖥️ **Tu Plataforma** hace los cálculos, guarda tu progreso solo, y te muestra tu avance.
>
> 💡 **Si vas a cambiar de dispositivo** (por ejemplo, de tu celular a tu computador): antes de cambiar, entra a cualquier módulo y dale clic a "Descargar mi progreso". Luego, en el otro dispositivo, entra a cualquier módulo, dale clic a "Cargar mi progreso" y selecciona el archivo que descargaste. Todo tu avance va a aparecer igual que lo dejaste.
>
> **FASE 1 · CLARIDAD** — Idea + Propósito (Semana 1)
> **FASE 2 · VALIDACIÓN** — Cliente + Prueba (Semana 2)
> **FASE 3 · ESTRUCTURA** — Finanzas + Modelo (Semana 3)
> **FASE 4 · LANZAMIENTO** — Ventas + Seguimiento (Semana 4)

---

## 2. Módulo por módulo

### Módulo 1 — Tu Propósito
- Reemplaza "📊 Conexión con tu Excel — Pestaña M1_PROPOSITO" por:
  > ✈ Completa tu Módulo 1 aquí → `https://[TU-SITIO].netlify.app/m1-proposito-mi-plan-de-vuelo.html`

### Módulo 2 — Tu Idea
- Link: `https://[TU-SITIO].netlify.app/m2-mi-idea-mi-plan-de-vuelo.html`
- ⚠️ **Corrección de contenido:** el filtro 5 debe decir *"¿Te emociona genuinamente?"* en vez de *"¿Puedes dedicarle al menos 20 minutos diarios sin sacrificar tu bienestar?"* (así coincide con la herramienta real).

### Módulo 3 — Tu Cliente
- Link: `https://[TU-SITIO].netlify.app/m3-mi-cliente-mi-plan-de-vuelo.html`

### Módulo 4 — Tu MVP
- Link: `https://[TU-SITIO].netlify.app/m4-mi-mvp-mi-plan-de-vuelo.html`
- ⚠️ **Corrección de página:** cambia "pág. 14" por **pág. 15–16**

### Módulo 5 — Finanzas
- Link: `https://[TU-SITIO].netlify.app/calculadora-finanzas-mi-plan-de-vuelo.html`
- ⚠️ **Agregar bloque nuevo** — texto completo abajo en la sección 3.

### Módulo 6 — Canvas
- Link: `https://[TU-SITIO].netlify.app/m6-canvas-mi-plan-de-vuelo.html`

### Módulo 7 — Tiempo
- Link: `https://[TU-SITIO].netlify.app/m7-tiempo-mi-plan-de-vuelo.html`
- ⚠️ **Corrección de contenido:** revisa que no quede ninguna mención de "30 minutos" — todo debe decir **20 minutos**

### Módulo 8 — Checklist
- Link: `https://[TU-SITIO].netlify.app/m8-checklist-mi-plan-de-vuelo.html`

### Módulo 9 — Ventas
- Link: `https://[TU-SITIO].netlify.app/m9-ventas-mi-plan-de-vuelo.html`
- ⚠️ **Corrección de contenido:** cambia "8 días de contenido" por **"9 días de contenido"** (aparece en la portada y en la introducción del módulo)

### Módulo 10 — Seguimiento
- Link: `https://[TU-SITIO].netlify.app/panel-seguimiento-mi-plan-de-vuelo.html`
- ⚠️ **Corrección de página:** cambia "pág. 40–43" por **pág. 40–44**

---

## 3. Texto nuevo para Módulo 5 — "¿Cuánto vale tu hora y tu trabajo?"

Pega este bloque después de la fórmula simple de precio, antes de la conexión con la herramienta:

> ### ¿Cuánto vale tu hora y tu trabajo?
>
> La fórmula de precio que ya viste (costo + tiempo + margen) tiene una trampa común: muchas mamás calculan el costo de los materiales, pero olvidan ponerle precio a su propio tiempo. Tu hora vale dinero, aunque estés en tu casa.
>
> **Paso 1 — Calcula cuánto vale tu hora**
> Divide tu meta de ingresos mensuales entre las horas que le dedicas al mes a tu negocio. Ese número es lo que vale cada hora tuya.
>
> **Paso 2A — Si vendes un producto físico o un servicio**
> Multiplica tu hora por el tiempo que tardas en producir 1 unidad o dar 1 sesión. Súmale tus costos variables (materiales, envío, etc). Multiplica el total por 1.5 — ese 50% extra es tu margen. Ese es tu precio sugerido.
>
> **Paso 2B — Si vendes un producto digital**
> Divide el tiempo total que tardaste en crear el producto entre las ventas que proyectas hacer. Súmale los costos de plataforma por venta. Multiplica por 1.5. Ese es tu precio digital sugerido.
>
> ✨ **El caso de Sofía — ¿Estoy cobrando lo justo?**
> Sofía ya había decidido cobrar $25/mes por su plan de menús. Pero quiso confirmar si ese precio era justo con su tiempo.
>
> Su meta mensual era $300, y le dedicaba 15 horas al mes a su negocio → su hora valía $20.
> Tardó 6 horas en crear el menú base, y proyectaba 12 suscriptoras al mes → el costo de su tiempo por venta era de $10 (($20 × 6) ÷ 12). Sumó $2 de costos de plataforma → $12 de costo total por venta. Multiplicado por 1.5, su precio mínimo debía ser $18.
>
> Sofía ya estaba cobrando $25 — $7 por encima de su mínimo. Ese cálculo no le dijo que subiera el precio: le confirmó que ya estaba cobrando con un margen sano, y le dio la tranquilidad de saber que no estaba regalando su tiempo.
>
> 💡 **Tip:** este cálculo no siempre te dice que subas el precio — a veces solo confirma que vas bien. Pero sin hacerlo, nunca lo sabrías con certeza.
>
> 🖥️ **Completa esto en tu Panel de Vuelo Financiero** → `https://[TU-SITIO].netlify.app/calculadora-finanzas-mi-plan-de-vuelo.html`

---

## Checklist final antes de exportar

- [ ] Cambié el hook de la portada (1.1)
- [ ] Reemplacé la página completa "Qué vas a lograr y cómo usar este kit" en Módulo 1, incluyendo el aviso de respaldo (1.2)
- [ ] Pegué los 10 links de módulos (reemplazando `[TU-SITIO]` por tu dominio real)
- [ ] Corregí el filtro 5 en Módulo 2
- [ ] Corregí la página en Módulo 4 (15–16)
- [ ] Agregué el bloque nuevo completo en Módulo 5
- [ ] Corregí "30 min" → "20 min" en Módulo 7
- [ ] Corregí "8 días" → "9 días" en Módulo 9
- [ ] Corregí la página en Módulo 10 (40–44)
- [ ] Exporté el PDF actualizado y lo subí en Hotmart (reemplazando el archivo actual)
